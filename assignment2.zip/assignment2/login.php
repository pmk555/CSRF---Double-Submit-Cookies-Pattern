<?php 

	//start session
	session_start();

	//set session ID to a variable
	$sessionID = session_id();

	//generate cookie foe 1 hour - HTTP ONLY
	setcookie("log_in",$sessionID,time()+3600,"/","localhost",false,true);

	if(empty($_SESSION['key']))
	{
		//generate a session key by converting random binaries to hex
		$_SESSION['key'] = bin2hex(random_bytes(32));
	}

	//Generate token by SHA256 Encryption,custom name and the session key
	$token = hash_hmac('sha256', 'login_csrf_token', $_SESSION['key']);

	//Initialize generated token in session variable
	$_SESSION['server_csrf'] = $token;

	//Initiate CSRF token embedded cookie for 1 hour
	setcookie("csrfToken",$token,time()+3600,"/","localhost",false,true);

?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">	
<link rel="stylesheet" type="text/css" href="login.css">
<script type="text/javascript" src="token.js"></script>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


</head>
<body>

<h6 style="color:LightGray;" >Assignment 01: Lokuge P.M.K. - IT18119336 [Username : Admin, Password : Lizzie]</h6>

<div class="wrapper fadeInDown">
	<div id="formContent">

	<form method="POST" action="server.php">
		
		<h3 style="text-align:center;">Login</h3><br/>
		<!--Username-->
		<input type="text" name="user" placeholder="Enter Username" required="required" class="form-control fadeIn second">
		<br/>
		<!--Password-->
		<input type="password" name="pwd" placeholder="Enter Password" required="required" class="form-control fadeIn third">
		<br/>
		<!--CSRF hidden field-->
		<input type="hidden" name="csrf" id="csrf_token" value="<?php echo $token; ?>" />

		<!--Submit button-->
		<button type="submit" name="submit" class="btn btn-primary">Login</button>	

	</form>

</div>
</div>

</body>
</html>
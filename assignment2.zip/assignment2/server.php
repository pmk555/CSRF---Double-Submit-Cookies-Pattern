<?php

	//session start
	session_start();


if(isset($_POST['submit']))
	{
		//clear memory buffer records
		ob_end_clean();
		
		//call POST variables for validation function
		validate($_POST['user'],$_POST['pwd'],$_POST['csrf'],$_COOKIE['log_in']);


	}
	

//validate function

function validate($username, $password, $user_csrf, $user_sessionCookie)
{
	if($username == "Admin" && $password == "Lizzie")
	{
		

		//validating csrf token with the cookie
		if( $user_csrf == $_SESSION['server_csrf'] && $user_sessionCookie == session_id())
		{
			
			header("Location:index.html");
		}
		else
		{
			echo "CSRF Failure"."<br/>";
			echo "User Token : ".$user_csrf."<br/>";
			echo "Server Token :".$_SESSION['server_csrf']."<br/>"; 
			exit();
		}
	}
	else
	{
			
			header("Location:login.php");		
           
			
	}
	

}	

?>




